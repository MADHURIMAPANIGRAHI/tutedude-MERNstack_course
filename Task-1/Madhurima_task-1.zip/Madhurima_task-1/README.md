Task 1 - Hello World
This is a simple HTML file that displays "Hello World!" in the browser.

How to run
Open index.html in any browser.